obj = [

// AVOID USING SPECIAL CHARACTERS LIKE ! AND ? IN THE TITLE
// JUST COPY PASTE THE LINE AND CHANGE THE TEXT TO MAKE A NEW ENTRY
// POSTS ARE ORDERED BOTTOM TO TOP



{"title": "Example Issue", "cardtext": "Click this for a rundown on how this website was created!", "content": "Hello readers! <br>This is an example issue! Everything here is changable with data.js in the js folder. Just copy and paste the line and switch out some text! Everything is sorted by top or bottom first, you choose with your dates.", "date": "8/6/2019", "banner": "https://cdn.insidetheperimeter.ca/wp-content/uploads/2019/04/BH-M87-768x447.jpg", "writer": "Rohin", "subtitle": "Example issue", "authortag": "Chief Officer, Design & Web Relations."},




]